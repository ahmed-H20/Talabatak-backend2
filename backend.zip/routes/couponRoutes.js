import express from 'express';
import { 
    createCoupon,
    getCoupons,
    getCoupon,
    updateCoupon,
    deleteCoupon,
    useCoupon
    } 
from '../controllers/couponController.js';
//import { getCouponValidator, createCouponValidator, updateCouponValidator, deleteCouponValidator } from '../utils/validators/CouponValidator.js';
import {protectRoute} from "../middlewares/protectRoute.js";
import authorizeRoles from '../middlewares/authorizeRoles.js';
const router = express.Router();

router.use(protectRoute, authorizeRoles('admin'));

router.route('/create')
    .post(createCoupon);
router.route('/getCoupons')
    .get(getCoupons);
router.route('/:id')
    .get(getCoupon);
router.route('/update/:id')
    .put(updateCoupon)
router.route('/delete/:id')
    .delete(deleteCoupon);
router.route('/useCoupon')
    .post(useCoupon);


export default router;