import Product from "../models/productModel.js"
import category from "../models/categoryModel.js"
import asyncHandler from "../middlewares/asyncHandler.js"

// @desc    Create a new product (Admin)
// @route   POST /api/products
// @access  Private/Admin
export const createProduct = asyncHandler(async (req, res) => {
  const { name, description, price, discount ,quantity, store, category,subCategory } = req.body;

  if (!name || !description || !price || !quantity || !store || !category) {
    throw new apiError("All required fields must be provided", 400);
  }

  const product = await Product.create({
    name,
    description,
    price,
    quantity,
    store,
    category,
    discount: req.body.discount || 0, // Default to 0 if not provided
    subCategory,
    images: req.body.images || [{url: "https://img.icons8.com/color/48/small-business.png"}],
  });
  await product.populate([
    { path: 'category', select: '-_id name' },
    { path: 'store', select: '-_id name' },
    { path: 'subCategory', select: '-_id name' }
  ]);
  
  res.status(201).json({
    message: "Product created successfully",
    data: product,
  });
});


// @desc    Get all products (Public)
// @route   GET /api/products
// @access  Public
export const getAllProducts = asyncHandler(async (req, res) => {
  const products = await Product.find().populate([
    { path: 'category', select: '-_id name' },
    { path: 'store', select: '-_id name' },
    { path: 'subCategory', select: '-_id name' }
  ]);

  const formattedProducts = products.map((product) => {
    const discount = product.discount || 0;
    const discountedPrice = product.price * (1 - discount / 100);

    return {
      ...product.toObject(),
      discountedPrice: +discountedPrice.toFixed(2),
    };
  });
  res.status(200).json({
    message: "All products fetched",
    data: formattedProducts,
  });
});

// @desc    Get single product by ID
// @route   GET /api/products/:id
// @access  Public
export const getProductById = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id).populate([
    { path: 'category', select: '-_id name' },
    { path: 'store', select: '-_id name' },
    { path: 'subCategory', select: '-_id name' }
  ]);

  if (!product) {
    throw new apiError("Product not found", 404);
  }

  const discount = product.discount || 0;
  const discountedPrice = product.price * (1 - discount / 100);

  res.status(200).json({
    message: "Product fetched successfully",
    data: {
      ...product.toObject(),
      discountedPrice: +discountedPrice.toFixed(2),
    },
  });
});

// @desc    Update product
// @route   PUT /api/products/:id
// @access  Private/Admin
export const updateProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id).populate([
    { path: 'category', select: '-_id name' },
    { path: 'store', select: '-_id name' },
    { path: 'subCategory', select: '-_id name' }
  ]);

  if (!product) {
    res.status(404);
    throw new Error("Product not found");
  }

  const {
    name,
    description,
    images,
    price,
    quantity,
    discount,
    store,
    category,
    subCategory
  } = req.body;

  if (name !== undefined) product.name = name;
  if (description !== undefined) product.description = description;
  if (images !== undefined) product.images = images;
  if (price !== undefined) product.price = price;
  if (quantity !== undefined) product.quantity = quantity;
  if (discount !== undefined) product.discount = discount;
  if (store !== undefined) product.store = store;
  if (category !== undefined) product.category = category;
  if (subCategory !== undefined) product.subCategory = subCategory;
  
  const updatedProduct = await product.save();
  res.status(200).json(updatedProduct);
});


// @desc    Delete product
// @route   DELETE /api/products/:id
// @access  Private/Admin
export const deleteProduct = asyncHandler(async (req, res) => {
const product = await Product.findByIdAndDelete(req.params.id
);
  if (!product) {
    res.status(404)
    throw new Error("Product not found")
  }

  res.status(200).json({ message: "Product deleted" })
});

// @desc    Increase all product prices for a specific store by a given percentage
// @route   PUT /api/products/increase-prices/:storeId
// @access  Private/Admin
export const increasePricesByPercentage = asyncHandler(async (req, res) => {
  const { storeId } = req.params;
  const { percentage } = req.body;

  if (!percentage || isNaN(percentage) || percentage <= 0) {
    throw new Error("Please provide a valid percentage greater than 0");
  }

  const factor = 1 + percentage / 100;

  const result = await Product.updateMany(
    { store: storeId },
    [
      {
        $set: {
          price: { $multiply: ["$price", factor] }
        }
      }
    ]
  );
  res.status(200).json({
    message: `Prices increased by ${percentage}% for ${result.modifiedCount} product(s).`,
  });
});


